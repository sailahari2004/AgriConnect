import React from 'react';
import Footer from '../component/Footer';

const HelpCenter = () => {
  return (
    <>
    <div className="max-w-3xl mx-auto p-6 mt-8 bg-white shadow-md rounded-lg">
      <h1 className="text-3xl font-bold text-green-700 mb-6">Help Center</h1>

      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-800">🔐 Account Help</h2>
        <p className="text-gray-600 mt-2">Need help with logging in, resetting your password, or updating profile info? Make sure you're using the correct email and password. Contact us if you're still facing issues.</p>
      </div>

      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-800">📦 Order Support</h2>
        <p className="text-gray-600 mt-2">Track your orders from your profile section. For delivery delays or payment issues, feel free to reach out via our support email.</p>
      </div>

      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-800">💬 Contact Us</h2>
        <p className="text-gray-600 mt-2">You can email us at <a href="tappitasailahari2004@gmail.com" className="text-green-600 underline">tappitasailahari2004@gmail.com</a> or call us at <span className="font-medium">+91 8247754500</span>.</p>
      </div>

      <div>
        <h2 className="text-xl font-semibold text-gray-800">❓FAQs</h2>
        <ul className="list-disc ml-6 text-gray-600 mt-2 space-y-2">
          <li>How do I change my password?</li>
          <li>What is your refund policy?</li>
          <li>How can I cancel my order?</li>
        </ul>
      </div>
    </div>
    <Footer/>
    </>
  );
};

export default HelpCenter;